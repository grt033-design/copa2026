// Netlify Function: proxy para a football-data.org
// Roda no servidor — sem CORS, sem expor a chave no frontend
const API_KEY = "45299c0f6b0c4378ac608d011783e099";
const BASE = "https://api.football-data.org/v4";

exports.handler = async (event) => {
  const { dateFrom, dateTo } = event.queryStringParameters || {};

  const url = `${BASE}/competitions/WC/matches?dateFrom=${dateFrom}&dateTo=${dateTo}`;

  try {
    const res = await fetch(url, {
      headers: { "X-Auth-Token": API_KEY }
    });

    const data = await res.json();

    return {
      statusCode: 200,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify(data)
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ error: err.message })
    };
  }
};
